package fpoly.ph45160.ph45160_and103_assignment.Cart;

public class TotaPriceResponse {
    private double totalPrice;

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
